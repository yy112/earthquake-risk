#' vectorize.R
#'
#' This function reads the data frames containing y, X, and information for i(district), t(time period) and p(type), and take the average over each i-t-p combination.
#'
#' @param data Input data frame.
#' @param colName.i Column name in data that contains district information.
#' @param colName.t Column name in data that contains time information.
#' @param colName.p Column name in data that contains type information.
#' @param colName.y Column name in data that contains the dependent variable.
#' @param colName.X Column name in data that contains the independent variables.
#'
#' @return A list containing: Unique name of districts, unique time periods, unique type names, Vector y, matrix X, and H (number of observations for each i-t-p combination).
#'
#' @import dplyr
#' @importFrom stats optim
#' @export


# The output is .
# All data should be numericals except for the
# columns containing i, t and p.


vectorize <- function(data, colName.i, colName.t, colName.p, colName.y, colName.X){
  # retrieve the unique names of district, time and type
  distr <- sort(unique(data[, colName.i]))
  time <- sort(unique(data[, colName.t]))
  type <- unique(data[, colName.p])
  # generate a tabulated dataframe
  tab <- expand.grid(type, distr, time)[, c(3, 2, 1)]
  colnames(tab) <- c(colName.t, colName.i, colName.p)
  # factorise the i/t/p columns so that they are ordered.
  # this is important for generating the averages.
  data[, colName.i] <- factor(x = data[, colName.i], levels = distr)
  data[, colName.t] <- factor(x = data[, colName.t], levels = time)
  data[, colName.p] <- factor(x = data[, colName.p], levels = type)
  # group data by i-t-p and take the means of each variable
  # result <- tab
  # result$H <- 0
  # result[, colName.y] <- 0
  # result[, colName.X] <- 0
  # for(i in 1:nrow(tab)){
  #   rows <- data[(data[, colName.t]==tab$t[i])&
  #     (data[, colName.i]==tab$Area.Ward.City[i])&
  #     (data[, colName.p]==tab$Type[i]), , drop=FALSE]
  #   result$H[i] <- nrow(rows)
  #   means <- sapply(Filter(is.numeric, rows), mean)
  #   result[i, colName.y] <- means[colName.y]
  #   result[i, colName.X] <- means[colName.X]
  #   if(i %% 10000 ==0){
  #     print(i)
  #   }

  sumstat <- data %>%
    dplyr::group_by_(colName.t, colName.i, colName.p) %>%
    dplyr::summarise_at(c(colName.X, colName.y), mean)
  sumH <- data %>%
    dplyr::group_by_(colName.t, colName.i, colName.p) %>%
    dplyr::summarise(n = n())
  # merge the name table "tab" with averages in table "sumstat"
  # and counts in table "sumH"
  result <- merge(tab, sumstat, all=TRUE)
  result <- merge(result, sumH, all=TRUE)
  # for(i in 1:nrow(sumcode)){
  #   rows <- which(result$StationCity==sumcode$StationCity[i])
  #   result$City.Town.Ward.Village.code[rows] <- sumcode$City.Town.Ward.Village.code[i]
  # }
  # for(i in 1:nrow(result)){
  #   if(!is.na(result[i, "n"])){
  #     xrows <- which(data[, colName.i]==result[i, colName.i] &
  #                      data[, colName.t]==result[i, colName.t])
  #     result[i, col.code] <- unique(data[xrows, col.code])[1]
  #   }
  # }
  y <- result[, colName.y]
  H <- result[, "n"]
  X <- result[, c(colName.t, colName.i, colName.p, colName.X)]
  # replace the NA rows with zero
  H[is.na(H)] <- 0
  y[is.na(y)] <- 0
  X[is.na(X)] <- 0
  #
  return(list("district" = distr, "time" = time, "type" = type,
              "H" = H, "y" = y, "X" = X))

}
