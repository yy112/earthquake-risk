#' Derivative of the Prelec probability weighting function
#'
#' A function that calculates the first derivative of the probability weighting function w.r.t. its parameter.
#' @param p Original probability, numeric value between 0 and 1.
#' @param psi Parameter of the function (single parameter form).
#' @param log Logical value indicating whether the weighted probability is taken natural logarithm. Default value is FALSE.
#'
#' @return Derivative of the Prelec function w.r.t. psi evaluated at p, a numeric value.
#'
#' @examples
#' Z_prelec(0.5,3)
#' Z_prelec(0.5, 0.5, log = TRUE)
#'
#' @export

Z_prelec <- function(p, psi, log = FALSE){
  if(log == FALSE){
    z <- ifelse(p!=0, exp(-  (-log(p)) ^ psi) * (- ((-log(p)) ^ psi)) * log(-log(p)),
                0)
  } else{
    z <- ifelse(p!=0, (- ((-log(p)) ^ psi)) * log(-log(p)),
                0)
  }
  return(z)
}
