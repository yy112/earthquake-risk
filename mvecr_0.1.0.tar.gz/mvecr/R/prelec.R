#' Prelec probability weighting function
#'
#' A function that converts probability into weighted probability using the Prelec(1998) functional form.
#'
#' @param p Original probability, numeric value between 0 and 1.
#' @param psi Parameter of the function (single parameter form).
#' @param psi2 Optional, second parameter of the function (two parameter form). Default value is 1 in which case the function degenerates into single parameter form.
#'
#' @return Weighted probability, numeric value between 0 and 1.
#'
#' @examples
#' prelec(0.2, 0.5)
#' prelec(0.2, 5)
#'
#' @references Prelec D. The probability weighting function[J]. ECONOMETRICA-EVANSTON ILL-, 1998, 66: 497-528.
#'
#' @export

prelec <- function(p, psi, psi2 = 1){
  w = ifelse(p!=0, exp(- psi2 * (-log(p)) ^ psi), 0)
  return(w)
}
