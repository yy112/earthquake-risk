#' reg_psi.R
#'
#' When one of the regressors depend on a parameter (psi), adjust the corresponding variance of beta and calculate the variance of psi. Here we assume Xpsi(psi) is a function of Xpsi_obj with parameter psi. The functional form can be a Prelec function (method="p") or a Tversky-Kahneman function (method="t").
#' @param data_X Matrix of independent variables.
#' @param data_y Vector of dependent variables.
#' @param data_H Vector of number of observations in each i-t-p combination.
#' @param colName.i Column name in data that contains district information.
#' @param colName.t Column name in data that contains time information.
#' @param colName.p Column name in data that contains type information.
#' @param psi A numeric value of the psi parameter.
#' @param method A character indicating which weighting function to choose. Options are "p" (prelec function) or "t" (tversky function).
#' @param district Unique name of districts.
#' @param time Unique time periods in the data.
#' @param type Unique names of the type in the data.
#' @param var Vector of names of the columns in data_X to include in the regression.
#' @param par.include A vector of logical values indicating whether or not to include a certain parameter in the regression. If FALSE, the parameter is constrained to be 0.
#' @param par.init A vector of initial value of the parameters. Default value is 0.5 for each parameter. The number of parameter is determined by \eqn{p*(1+p)/2 * [number of error components]}.
#' @return results, a dataframe containing parameter estimates, t statistics, loglikelihood value, value of psi (given as input), and the t-statistic w.r.t. psi.
#'
#' @export
reg_psi <- function(data_X, data_y, data_H,
                    colName.i = "i", colName.t = "t",  colName.p = "Type",
                    psi = 1, method = "p",
                    district, time, type,
                    var,
                    par.include = rep(1, 18),
                    par.init = rep(0.5, 18)){
  if(! "Xpsi"%in%var){
    print("Xpsi not in list of regressors!")
    return(0)
  } else{
    data_X$Xpsi <- 0
    if(method == "p"){
      data_X$Xpsi <- ifelse(data_X$Xpsi_obj==0, 0, prelec(data_X$Xpsi_obj, psi = psi))
      z_psi <-  Z_prelec(p = (data_X$Xpsi_obj), psi = psi, log = FALSE)
      Hz <- as.vector(sqrt(data_H)) * z_psi
    } else if(method == "t"){
      data_X$Xpsi <- ifelse(data_X$Xpsi_obj==0, 0, tversky(data_X$Xpsi_obj, psi = psi))
      z_psi <-  Z_tversky(p = (data_X$Xpsi_obj), psi = psi, log = FALSE)
      Hz <- as.vector(sqrt(data_H)) * z_psi
    }
    include_2error <- c(rep(1, 6), rep(0,6), rep(1,6))
    # include_3error <- rep(1, 18)
    initpar <- c(-1.5, 0.1, -0.1, -2.1, -0.01, -1.1,
                 -2.5, 0.02, -0.1, -3.5,  0.1, -3.5,
                 -0.9, 0.008, 0.005, -0.9, 0.01, -0.9)
    results <- ec_reg(data_X,  data_y, data_H,
                      colName.i = "Area.Ward.City", colName.t = "t",
                      colName.p = "Type",
                      var = var,
                      district = district, time = time, type = type,
                      par.include = include_2error,
                      par.init = initpar)
    # given the regression results, reconstruct the variances
    N <- length(district)
    Tn <- length(time)
    p <- length(type)
    Hy <- as.vector(sqrt(data_H)) * data_y
    Hy[data_H==0] <- 0
    HX <- as.vector(sqrt(data_H)) * data_X[, var]
    HX[data_H==0, ] <- 0
    HX <- as.matrix(HX)
    par.include <- include_2error
    npar <- sum(par.include!=0)
    par <- results$par.wgr[1:npar]
    full.par <- rep(0, 3*p*(p+1)/2)
    full.par[which(par.include!=0)] <- par
    full.par <- matrix(full.par, ncol=3, byrow = F)
    tmp <- matrix(0, p, p)
    L.zeta <- tmp
    L.zeta[lower.tri(tmp, diag = T)] <- full.par[, 1]
    diag(L.zeta) <- exp(diag(L.zeta)) * par.include[c(1, 4, 6)]
    L.eta <- tmp
    L.eta[lower.tri(tmp, diag = T)] <- full.par[, 2]
    diag(L.eta) <- exp(diag(L.eta)) * par.include[c(7, 10, 12)]
    L.eps <- tmp
    L.eps[lower.tri(tmp, diag = T)] <- full.par[, 3]
    diag(L.eps) <- exp(diag(L.eps)) * par.include[c(13, 16, 18)]
    # generate sigma_zeta, sigma_eta, sigma_eps
    sigmazeta <-  tcrossprod(L.zeta)
    sigmaeta <- tcrossprod(L.eta)
    sigmaeps <- tcrossprod(L.eps)
    Omega1 <- sigmaeps + Tn * sigmazeta + N * sigmaeta
    Omega2 <- sigmaeps + Tn * sigmazeta
    Omega3 <- sigmaeps +  N * sigmaeta
    Omega4 <- sigmaeps
    O1inv <- solve(Omega1)
    O2inv <- solve(Omega2)
    O3inv <- solve(Omega3)
    O4inv <- solve(Omega4)
    XOX <- X_invOmega_Y(HX, HX, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    XOy <- X_invOmega_Y(HX, Hy, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    V11inv <- solve(XOX)
    V12 <- X_invOmega_Y(HX, Hz, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    V21 <- X_invOmega_Y(Hz, HX, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    V22 <- X_invOmega_Y(Hz, Hz, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    beta <- solve(XOX, XOy)
    beta_k <- results$coef[which(results$var=="Xpsi")]
    var_beta <- V11inv + V11inv %*% V12 %*% V21 %*% V11inv /
      as.numeric((V22 - V21 %*% V11inv %*% V12))
    t_beta <- beta/sqrt(diag(var_beta))
    results$t.stat <- as.vector(t_beta)
    var_psi <- 1/ ( beta_k^2 * (V22 - V21 %*% V11inv %*% V12) )
    tstat_psi <- (psi-1) / sqrt(var_psi)
    results_psi <- rbind(results, c(-results$val[1], 0,0,0,0, psi, tstat_psi))
  }
  return(results_psi)
}
