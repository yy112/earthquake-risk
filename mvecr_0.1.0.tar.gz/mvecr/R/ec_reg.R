#' ec_reg.R
#'
#' This function implements the main optimization procedure for the regression model with multivariate error components.
#'
#' @param data_X Matrix of independent variables.
#' @param data_y Vector of dependent variables.
#' @param data_H Vector of number of observations in each i-t-p combination.
#' @param colName.i Column name in data that contains district information.
#' @param colName.t Column name in data that contains time information.
#' @param colName.p Column name in data that contains type information.
#' @param district Unique name of districts.
#' @param time Unique time periods in the data.
#' @param type Unique names of the type in the data.
#' @param var Vector of names of the columns in data_X to include in the regression.
#' @param par.include A vector of logical values indicating whether or not to include a certain parameter in the regression. If FALSE, the parameter is constrained to be 0.
#' @param par.init A vector of initial value of the parameters. Default value is 0.5 for each parameter. The number of parameter is determined by \eqn{p*(1+p)/2 * [number of error components]}.
#' @return results, a dataframe containing parameter estimates and t statistics.
#'
#' @export

ec_reg <- function(data_X, data_y, data_H,
                   colName.i = "i", colName.t = "t",  colName.p = "Type",
                   district, time, type,
                   var,
                   par.include = rep(1, 18),
                   par.init = rep(0.5, 18)){
  # The main optimization procedure for the regression model with multivariate error components.
  N <- length(district)
  Tn <- length(time)
  X.num <- data_X[, var]
  k <- length(var)
  p <- length(type)
  # supplementary matrices
  JT <- matrix(1, ncol=Tn, nrow=Tn)/Tn
  JN <- matrix(1, ncol=N, nrow=N)/N
  Xnum <- X.num
  for(i in 1:ncol(Xnum)){
    Xnum[,i]<-as.numeric(Xnum[,i])
  }
  Hy <- as.vector(sqrt(data_H)) * data_y
  Hy[data_H==0] <- 0
  HX <- as.vector(sqrt(data_H)) * Xnum
  HX[data_H==0, ] <- 0
  HX <- as.matrix(HX)
  # do optimization
  results <- data.frame(var = character(k),
                        par.wgr = numeric(k),
                        count.wgr  = numeric(k),
                        gradient = numeric(k),
                        val = numeric(k),
                        coef = numeric(k),
                        t.stat = numeric(k))

  init <- par.init[par.include==1]
  result.wgr <- optim(par = init, fn=negloglik, gr=gradient,
                      include = par.include, N = N, Tn = Tn, p = p,HX = HX, Hy = Hy,
                      method="L-BFGS-B", hessian = T,
                      control = list(trace = 2, maxit = 500))
  results$var <- var
  results$par.wgr[1:sum(par.include)] <- result.wgr$par
  results$count.wgr[1] <- result.wgr$counts[1]
  results$val[1] <- result.wgr$value[1]
  par <- result.wgr$par
  npar <- length(par)
  full.par <- rep(0, 3*p*(p+1)/2)
  full.par[which(par.include!=0)] <- par
  full.par <- matrix(full.par, ncol=3, byrow = F)
  tmp <- matrix(0, p, p)
  L.zeta <- tmp
  L.zeta[lower.tri(tmp, diag = T)] <- full.par[, 1]
  diag(L.zeta) <- exp(diag(L.zeta)) * par.include[c(1, 4, 6)]
  L.eta <- tmp
  L.eta[lower.tri(tmp, diag = T)] <- full.par[, 2]
  diag(L.eta) <- exp(diag(L.eta)) * par.include[c(7, 10, 12)]
  L.eps <- tmp
  L.eps[lower.tri(tmp, diag = T)] <- full.par[, 3]
  diag(L.eps) <- exp(diag(L.eps)) * par.include[c(13, 16, 18)]
  # generate sigma_zeta, sigma_eta, sigma_eps
  sigmazeta <-  tcrossprod(L.zeta)
  sigmaeta <- tcrossprod(L.eta)
  sigmaeps <- tcrossprod(L.eps)
  Omega1 <- sigmaeps + Tn * sigmazeta + N * sigmaeta
  Omega2 <- sigmaeps + Tn * sigmazeta
  Omega3 <- sigmaeps +  N * sigmaeta
  Omega4 <- sigmaeps
  O1inv <- solve(Omega1)
  O2inv <- solve(Omega2)
  O3inv <- solve(Omega3)
  O4inv <- solve(Omega4)
  XOX <- X_invOmega_Y(HX, HX, N, Tn, p,
                      O1inv, O2inv, O3inv, O4inv)
  XOy <- X_invOmega_Y(HX, Hy, N, Tn, p,
                      O1inv, O2inv, O3inv, O4inv)
  V11inv <- solve(XOX)
  beta <- solve(XOX, XOy)
  results$coef <- as.vector(beta)
  var_beta <- V11inv
  t_beta <- beta/sqrt(diag(var_beta))
  results$t.stat <- as.vector(t_beta)
  return(results)
}
