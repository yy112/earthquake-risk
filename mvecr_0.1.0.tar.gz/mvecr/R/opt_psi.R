#' opt_psi.R
#'
#' Given a list of parameter psi's,  this function finds the psi that maximizes loglikelihood.
#'
#' @param data_X Matrix of independent variables.
#' @param data_y Vector of dependent variables.
#' @param data_H Vector of number of observations in each i-t-p combination.
#' @param list_psi A numeric vector of the psi parameter.
#' @param method A character indicating which weighting function to choose. Options are "p" (prelec function) or "t" (tversky function).
#' @param district Unique name of districts.
#' @param time Unique time periods in the data.
#' @param type Unique names of the type in the data.
#' @param var Vector of names of the columns in data_X to include in the regression.
#' @param par.include A vector of logical values indicating whether or not to include a certain parameter in the regression. If FALSE, the parameter is constrained to be 0.
#' @param par.init A vector of initial value of the parameters. Default value is 0.5 for each parameter. The number of parameter is determined by \eqn{p*(1+p)/2 * [number of error components]}.
#' @param plot A logical value indicating whether or not to plot a simple graph of the likelihood curve.
#'
#' @return Numeric value of the psi parameter that maximizes loglikelihood.
#'
#' @export
opt_psi <- function(data_X, data_y, data_H,
                    list_psi = 1, method = "p",
                    district, time, type,
                    var,
                    par.include = rep(1, 18),
                    par.init = rep(0.5, 18),
                    plot = FALSE){
  list_logL <- numeric(length(list_psi))
  for(i in 1:length(list_psi)){
    res <- reg_psi(data_X, data_y, data_H,
                   psi = list_psi[i], method = "p",
                   district = district, time = time, type = type,
                   var = var,
                   par.include,
                   par.init)
    list_logL[i] <- -res$val[1]
  }
  if(plot==TRUE){
    plot(list_psi, list_logL)
  }
  return(list_psi[which.max(list_logL)])
}
