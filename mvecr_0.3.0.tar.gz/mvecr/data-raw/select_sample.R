# select sample from raw data


set.seed(500)
distrs <- sample(unique(individual_data$Area.Ward.City), 1000, replace = FALSE)
Xnames_sample <- c("log.price", "Area.Ward.City", "t", "Type",
  "constant_LandBldg", "constant_LandOnly", "constant_Condo",
                 "distance.num", "area.m2.num", "total.floor.area.m2.num",
                 "building.age",
                 "LandBldg_RC", "LandBldg_S", "LandBldg_W",
                 "built.1981_2000", "built.after2000" ,
                 "Urban_Control",
                 "max.building.coverage.ratio", "max.floor.area.ratio",
                 "City_Fukuoka", "City_Nagoya", "City_Osaka", "City_Sapporo",
                 "log.nGDP", "log.CPI",
                 "PctImmi", "Ncrime", "PctUnemploy", "PctExec",
                 "JSHIS_I45_55", "JSHIS_I55", "Xpsi_obj")


individual_data_sample <- individual_data %>%
  filter(Area.Ward.City %in% distrs) %>%
  select(all_of(Xnames_sample))

use_data(individual_data_sample)
