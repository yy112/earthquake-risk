#' "Tversky and Kahneman" probability weighting function
#'
#' A function that converts probability into weighted probability using the functional form introduced in Tversky and Kahneman (1992).
#'
#' @param p Original probability, numeric value between 0 and 1.
#' @param psi Parameter of the function (single parameter form). Default value is 1 in which case the function degenerates into identity function w(p)=p.
#'
#' @return Weighted probability, numeric value between 0 and 1.
#'
#' @examples
#' tversky(0.2, 0.5)
#' tversky(0.2, 5)
#' @references Tversky, A., & Kahneman, D. (1992). Advances in prospect theory: Cumulative representation of uncertainty. Journal of Risk and uncertainty, 5(4), 297-323.
#'@export
tversky <- function(p, psi = 1){
w <- ifelse(p!=0, p^psi / (p^psi + (1-p)^psi)^(1/psi), 0)
return(w)
}
