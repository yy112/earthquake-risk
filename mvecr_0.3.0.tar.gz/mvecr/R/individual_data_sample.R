#' A sample of housing transaction data with macroeconomic variables, demographic characterics and earthquake risk probabilities
#'
#' A dataset containing the prices and other attributes of housing transaction records.
#'
#' @format A data frame of 92478 rows and 32 variables:
#' \describe{
#'   \item{log.price}{natural logarithm of housing transaction price, in Japanese Yen}
#'   \item{Area.Ward.City}{name of the district (area), ward, and city that the property is located in}
#'   \item{t}{transaction time, in quarters, e.g. "2020 Q3"}
#'   \item{Type}{type of the property, which can be of value "Residential Land(Land Only)", "Residential Land(Land and Building)", or "Pre-owned Condominiums, etc."}
#'   \item{constant_LandBldg}{a dummy variable indicating whether the property type is "Residential Land(Land and Building)"}
#'   \item{constant_LandOnly}{a dummy variable indicating whether the property type is "Residential Land(Land Only)"}
#'   \item{constant_Condo}{a dummy variable indicating whether the property type is "Pre-owned Condominiums, etc."}
#'   \item{distance.num}{distance to the nearest station, in terms of minutes in walking}
#'   \item{area.m2.num}{area of the property, in square meters}
#'   \item{total.floor.area.m2.num}{total floor area of the property, in square meters}
#'   \item{building.age}{age of the building}
#'   \item{LandBldg_RC}{dummy variable indicating whether the property is of type "Residential Land(Land and Building)" and building structure is primarily Reinforced Concrete}
#'   \item{LandBldg_S}{dummy variable indicating whether the property is of type "Residential Land(Land and Building)" and building structure is primarily Steel}
#'   \item{LandBldg_W}{dummy variable indicating whether the property is of type "Residential Land(Land and Building)" and building structure is primarily Wood}
#'   \item{built.1981_2000}{dummy variable indicating whether the property is built between 1981 and 2000}
#'   \item{built.after2000}{dummy variable indicating whether the property is built after 2000}
#'   \item{Urban_Control}{dummy variable indicating whether the property is in an "Urban Control" area}
#'   \item{max.building.coverage.ratio}{maximum allowed building coverage ratio (BCR)}
#'   \item{max.floor.area.ratio}{maximum allowed floor area ratio (FAR)}
#'   \item{City_Fukuoka}{dummy variable indicating whether the property is located in the city of Fukuoka}
#'   \item{City_Nagoya}{dummy variable indicating whether the property is located in the city of Nagoya}
#'   \item{City_Osaka}{dummy variable indicating whether the property is located in the city of Osaka}
#'   \item{City_Sapporo}{dummy variable indicating whether the property is located in the city of Sapporo}
#'   \item{log.nGDP}{natural logarithm of nominal GDP of the year of transaction}
#'   \item{log.CPI}{natural logarithm of the CPI of the year of transaction}
#'   \item{PctImmi}{average percentage of immigrants in the ward where the property is located in}
#'   \item{Ncrime}{average number of crimes in the ward where the property is located in}
#'   \item{PctUnemploy}{average percentage of unemployed in the ward where the property is located in}
#'   \item{PctExec}{average percentage of executives in the ward where the property is located in}
#'   \item{JSHIS_I45_55}{long run earthquake probabilities that an earthquake of intensity between "5 lower" and "6 lower" occurs within the next 30 years}
#'   \item{JSHIS_I55}{long run earthquake probabilities that an earthquake of intensity above "6 lower" occurs within the next 30 years}
#'   \item{Xpsi_obj}{short run "objective" earthquake probabilities}
#'
#' }
#' @references Ikefuji, M., Laeven, R. J., Magnus, J. R., & Yue, Y. (2020). Earthquake risk embedded in property prices: Evidence from five Japanese cities - Data documentation.
#' @source See references.
"individual_data_sample"
