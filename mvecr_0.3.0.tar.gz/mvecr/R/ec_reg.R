#' Maximum likelihood estimation of the multivariate error components model
#'
#' This function implements the maximum likelihood estimation procedure for the regression model with multivariate error components.
#'
#' @param data.X A matrix containing independent variables.
#' @param data.y A vector of dependent variables.
#' @param data.H A vector of the number of observations in each t-i-p combination.
#' @param colName.i Name of the column in data.X that contains "district" information.
#' @param colName.t Name of the column in data.X that contains "time" information.
#' @param colName.p Name of the column in data.X that contains "type" information.
#' @param district A vector of the unique names of districts.
#' @param time A vector of the unique time periods in the data.
#' @param type A vector of the unique names of types in the data.
#' @param var A vector of the names of the columns in data.X to be included as regressors in the regression.
#' @param par.include A vector of logical values indicating whether or not to include a certain error parameter in the regression. If FALSE, the parameter is constrained to be 0. The error parameters are the non-zero elements of the Cholesky decomposition of the variance-covariance matrices of each error component. The dimension of each error matrix will be \eqn{p\times p}, corresponding to \eqn{p*(1+p)/2} parameters. Default value of par.include is \eqn{rep(1, 18)} for a three error component model with \eqn{p=3}, where \eqn{p} is the number of distinct types (the length of vector in each t-i combination). The first \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\zeta}} (district specific error component), the second \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\eta}} (time specific error component), and the last \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\eps}} (individual specific error component).
#' @param par.init A vector of initial values of the parameters. Default value is 0.5 for each parameter. The number of parameters is \eqn{3*p*(1+p)/2}, where \eqn{p} is the number of types and 3 is the number of error components in the full model. Note that the parameters corresponding to the elements of "par.include" being FALSE are constrained to be 0, so even if initial parameters are specified for these parameters, they will not be used.
#' @return results, a dataframe containing parameter estimates and t statistics.
#'
#' @references Ikefuji, M., Laeven, R. J., Magnus, J. R., & Yue, Y. (2020). Earthquake risk embedded in property prices: Evidence from five Japanese cities.
#' @examples
#' \dontrun{
#' vars_include <- c("constant_LandBldg", "constant_LandOnly", "constant_Condo",
#' "distance.num", "area.m2.num", "total.floor.area.m2.num", "building.age",
#' "LandBldg_RC", "LandBldg_S", "LandBldg_W", "built.1981_2000", "built.after2000",
#' "Urban_Control", "max.building.coverage.ratio", "max.floor.area.ratio",
#' "City_Fukuoka", "City_Nagoya", "City_Osaka", "City_Sapporo", "log.nGDP", "log.CPI",
#' "PctImmi", "Ncrime", "PctUnemploy", "PctExec", "JSHIS_I45_55", "JSHIS_I55")
#' data_vec <- vectorize(data = individual_data_sample,
#' colName.i = "Area.Ward.City",
#' colName.t = "t", colName.p = "Type",
#' colName.y = "log.price",
#' colName.X = vars_include)
#' results <- ec_reg(data.X = data_vec$X, data.y = data_vec$y, data.H = data_vec$H,
#' colName.i = "Area.Ward.City", colName.t = "t",  colName.p = "Type",
#' district = data_vec$district, time = data_vec$time, type = data_vec$type,
#' var = vars_include,
#' par.include = c(rep(1, 6), rep(0,6), rep(1,6)))
#' }
#' @export

ec_reg <- function(data.X, data.y, data.H,
                   colName.i, colName.t,  colName.p,
                   district, time, type,
                   var,
                   par.include = rep(1, 18),
                   par.init = rep(0.5, 18)){
  # The main optimization procedure for the regression model with multivariate error components.
  N <- length(district)
  Tn <- length(time)
  X.num <- data.X[, var]
  k <- length(var)
  p <- length(type)
  # supplementary matrices
  JT <- matrix(1, ncol=Tn, nrow=Tn)/Tn
  JN <- matrix(1, ncol=N, nrow=N)/N
  Xnum <- X.num
  for(i in 1:ncol(Xnum)){
    Xnum[,i]<-as.numeric(Xnum[,i])
  }
  Hy <- as.vector(sqrt(data.H)) * data.y
  Hy[data.H==0] <- 0
  HX <- as.vector(sqrt(data.H)) * Xnum
  HX[data.H==0, ] <- 0
  HX <- as.matrix(HX)
  # do optimization
  results <- data.frame(var = character(k),
                        param_est = numeric(k),
                        count_iter  = numeric(k),
                        gradient = numeric(k),
                        negLL = numeric(k),
                        coef = numeric(k),
                        t.stat = numeric(k))

  init <- par.init[par.include==1]
  result.wgr <- optim(par = init, fn=negloglik, gr=gradient,
                      include = par.include, N = N, Tn = Tn, p = p,HX = HX, Hy = Hy,
                      method="L-BFGS-B", hessian = T,
                      control = list(trace = 2, maxit = 500))
  results$var <- var
  results$param_est[1:sum(par.include)] <- result.wgr$par
  results$count_iter[1] <- result.wgr$counts[1]
  results$negLL[1] <- result.wgr$value[1]
  par <- result.wgr$par
  npar <- length(par)
  full.par <- rep(0, 3*p*(p+1)/2)
  full.par[which(par.include!=0)] <- par
  full.par <- matrix(full.par, ncol=3, byrow = F)
  tmp <- matrix(0, p, p)
  L.zeta <- tmp
  L.zeta[lower.tri(tmp, diag = T)] <- full.par[, 1]
  diag(L.zeta) <- exp(diag(L.zeta)) * par.include[c(1, 4, 6)]
  L.eta <- tmp
  L.eta[lower.tri(tmp, diag = T)] <- full.par[, 2]
  diag(L.eta) <- exp(diag(L.eta)) * par.include[c(7, 10, 12)]
  L.eps <- tmp
  L.eps[lower.tri(tmp, diag = T)] <- full.par[, 3]
  diag(L.eps) <- exp(diag(L.eps)) * par.include[c(13, 16, 18)]
  # generate sigma_zeta, sigma_eta, sigma_eps
  sigmazeta <-  tcrossprod(L.zeta)
  sigmaeta <- tcrossprod(L.eta)
  sigmaeps <- tcrossprod(L.eps)
  Omega1 <- sigmaeps + Tn * sigmazeta + N * sigmaeta
  Omega2 <- sigmaeps + Tn * sigmazeta
  Omega3 <- sigmaeps +  N * sigmaeta
  Omega4 <- sigmaeps
  O1inv <- solve(Omega1)
  O2inv <- solve(Omega2)
  O3inv <- solve(Omega3)
  O4inv <- solve(Omega4)
  XOX <- X_invOmega_Y(HX, HX, N, Tn, p,
                      O1inv, O2inv, O3inv, O4inv)
  XOy <- X_invOmega_Y(HX, Hy, N, Tn, p,
                      O1inv, O2inv, O3inv, O4inv)
  V11inv <- solve(XOX)
  beta <- solve(XOX, XOy)
  results$coef <- as.vector(beta)
  var_beta <- V11inv
  t_beta <- beta/sqrt(diag(var_beta))
  results$t.stat <- as.vector(t_beta)
  return(results)
}
