#' Function for the transformation of individual records into a stacked form
#'
#' This function reads the data frames containing y, X, and information for i(district), t(time period) and p(type), takes the average over each t-i-p combination, and stacks the averages into a vectorized form.
#'
#' @param data Input data frame. All data should be numericals except for the columns containing i, t and p.
#' @param colName.i Column name in data that contains "district" information.
#' @param colName.t Column name in data that contains "time" information.
#' @param colName.p Column name in data that contains "type" information.
#' @param colName.y Column name in data that contains the dependent variable.
#' @param colName.X Column name in data that contains the independent variables.
#'
#' @return A list containing: "district": unique names of districts, "time": unique time periods,
#' "type": unique type names, "H": number of observations for each t-i-p combination,
#' "y": average of the dependent variable for each t-i-p combination,
#' "X": average of the independent variables for each t-i-p combination.
#' @references Ikefuji, M., Laeven, R. J., Magnus, J. R., & Yue, Y. (2020). Earthquake risk embedded in property prices: Evidence from five Japanese cities.
#' @import dplyr
#' @importFrom stats optim
#' @examples
#' \dontrun{
#' vars_include <- c("constant_LandBldg", "constant_LandOnly", "constant_Condo",
#' "distance.num", "area.m2.num", "total.floor.area.m2.num", "building.age",
#' "LandBldg_RC", "LandBldg_S", "LandBldg_W", "built.1981_2000", "built.after2000",
#' "Urban_Control", "max.building.coverage.ratio", "max.floor.area.ratio",
#' "City_Fukuoka", "City_Nagoya", "City_Osaka", "City_Sapporo", "log.nGDP", "log.CPI",
#' "PctImmi", "Ncrime", "PctUnemploy", "PctExec", "JSHIS_I45_55", "JSHIS_I55", "Xpsi_obj")
#' data_vec <- vectorize(data = data_sample, colName.i = "Area.Ward.City",
#' colName.t = "t", colName.p = "Type",
#' colName.y = "log.price",
#' colName.X = vars_include)
#' }
#' @export





vectorize <- function(data, colName.i, colName.t, colName.p, colName.y, colName.X){
  # retrieve the unique names of district, time and type
  distr <- sort(unique(data[[colName.i]]))
  time <- sort(unique(data[[colName.t]]))
  type <- unique(data[[colName.p]])
  tab <- expand.grid(type, distr, time)[, c(3, 2, 1)]
  colnames(tab) <- c(colName.t, colName.i, colName.p)
  # factorise the i/t/p columns so that they are ordered.
  # this is important for generating the averages.
  data[, colName.i] <- factor(x = data[[colName.i]], levels = distr)
  data[, colName.t] <- factor(x = data[[colName.t]], levels = time)
  data[, colName.p] <- factor(x = data[[colName.p]], levels = type)
  # group data by i-t-p and take the means of each variable
  sumstat <- data %>%
    dplyr::group_by_at(c(colName.t, colName.i, colName.p), .drop=FALSE) %>%
    dplyr::summarise_at(c(colName.X, colName.y), mean)
  sumH <- data %>%
    dplyr::group_by_at(c(colName.t, colName.i, colName.p), .drop=FALSE) %>%
    dplyr::summarise(n = n())
  # merge the averages in table "sumstat" with the counts in table "sumH"
  result <- merge(tab, sumstat, all = TRUE)
  result <- merge(result, sumH, all = TRUE)
  result <- result %>% arrange(!!!syms(c(colName.t, colName.i, colName.p)))
  y <- result[[colName.y]]
  H <- result[["n"]]
  X <- result[, c(colName.t, colName.i, colName.p, colName.X)]
  # replace the NA rows with zero
  H[is.na(H)] <- 0
  y[is.na(y)] <- 0
  X[is.na(X)] <- 0
  #
  return(list("district" = distr, "time" = time, "type" = type,
              "H" = H, "y" = y, "X" = X))

}
