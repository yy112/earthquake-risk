#' Negative loglikelihood function
#'
#' This function is the negative loglikelihood function of the multivariate error component model.
#'
#' @param par A vector of parameters corresponding to the Cholesky decomposition of the error matrices, that is, \eqn{\Sigma=LL'} where \eqn{L} is a lower triangular matrix with positive diagonal elements). This vector is of length \eqn{3*p*(p+1)/2}, where 3 comes from the three error components. However, note that only the parameters corresponding to include=TRUE are included in the models while others are constrained to be 0. The first \eqn{p*(p+1)/2} parameters correspond to the error matrix \eqn{\Sigma_{\zeta}} (district specific error component), the second \eqn{p*(p+1)/2} parameters correspond to the error matrix \eqn{\Sigma_{\eta}} (time specific error component), and the last \eqn{p*(p+1)/2} parameters correspond to the error matrix \eqn{\Sigma_{\epsilon}} (individual specific error component).
#' @param include A vector of logical values with the same dimension as par, indicating whether the parameter should be included as one of the values to optimize on. If a certain element corresponds to include=FALSE, that parameter is constrained to be 0. Hence, for a "full" three error component model, set include=rep(1, \eqn{3*p*(p+1)/2}); for a two error component model with only district specific and individual specific errors, set include=c(rep(1, \eqn{p*(p+1)/2}), rep(0, \eqn{p*(p+1)/2}), rep(1, \eqn{p*(p+1)/2})).
#' @param N A numeric scalar, number of districts.
#' @param Tn A numeric scalar, number of time periods.
#' @param p A numeric scalar, number of types.
#' @param HX A numeric matrix of independent variables, with dimension \eqn{N*Tn*p\times k_1} where \eqn{k_1} is the number of regressors.
#' @param Hy A numeric vector of dependent variables, with dimension \eqn{N*Tn*p\times 1}.
#'
#' @return A numeric scalar of the negative loglikelihood of the multivariate error component model.
#' @references Ikefuji, M., Laeven, R. J., Magnus, J. R., & Yue, Y. (2020). Earthquake risk embedded in property prices: Evidence from five Japanese cities.
#' @export
negloglik <- function(par, include, N, Tn, HX, Hy, p){
  # include is the dummy for whether to include non-zero
  # theta parameters, in order of L.zeta, L.eta, L.eps, by col
  npar <- length(par)
  full.par <- rep(0, 3*p*(p+1)/2)
  full.par[which(include!=0)] <- par
  full.par <- matrix(full.par, ncol=3, byrow = F)
  tmp <- matrix(0, p, p)
  if(npar != sum(include) | length(include)!=(3*p*(p+1)/2)){
    print("number of parameters not match")
  } else if(p==3){
    L.zeta <- tmp
    L.zeta[lower.tri(tmp, diag = T)] <- full.par[, 1]
    diag(L.zeta) <- exp(diag(L.zeta)) * include[c(1, 4, 6)]
    L.eta <- tmp
    L.eta[lower.tri(tmp, diag = T)] <- full.par[, 2]
    diag(L.eta) <- exp(diag(L.eta)) * include[c(7, 10, 12)]
    L.eps <- tmp
    L.eps[lower.tri(tmp, diag = T)] <- full.par[, 3]
    diag(L.eps) <- exp(diag(L.eps)) * include[c(13, 16, 18)]
    # generate sigma_zeta, sigma_eta, sigma_eps
    sigmazeta <-  tcrossprod(L.zeta)
    sigmaeta <- tcrossprod(L.eta)
    sigmaeps <- tcrossprod(L.eps)
    # generate Omega matrices
    Omega1 <- sigmaeps + Tn * sigmazeta + N * sigmaeta
    Omega2 <- sigmaeps + Tn * sigmazeta
    Omega3 <- sigmaeps +  N * sigmaeta
    Omega4 <- sigmaeps
    O1inv <- solve(Omega1)
    O2inv <- solve(Omega2)
    O3inv <- solve(Omega3)
    O4inv <- solve(Omega4)
    XOX <- X_invOmega_Y(HX, HX, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    XOy <- X_invOmega_Y(HX, Hy, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    #print(solve(XOX))
    beta <- solve(XOX, XOy)
    # vectors of residuals, each column is for a different "type"
    # this is a (N*Tn) * p matrix
    # inside each col, {t1, i1}, {t1, i2}, {t1, i3}, ...{t2, i1}, {t2, i2}, {t2, i3}..
    vit <- Hy - HX %*% beta
    negll <- 1/2 * (log(det(Omega1)) + (N-1) * log(det(Omega2)) +
                      (Tn-1) * log(det(Omega3)) + (N-1) * (Tn-1) * log(det(Omega4)) +
                      X_invOmega_Y(vit, vit, N, Tn, p,
                                   O1inv, O2inv, O3inv, O4inv))

    return(negll)
  } else if(p==1){
    L.zeta <- exp(full.par[, 1]) * include[1]
    L.eta <- exp(full.par[, 2]) * include[2]
    L.eps <- exp(full.par[, 3]) * include[3]

    # generate sigma_zeta, sigma_eta, sigma_eps
    sigmazeta <-  tcrossprod(L.zeta)
    sigmaeta <- tcrossprod(L.eta)
    sigmaeps <- tcrossprod(L.eps)
    # generate Omega matrices
    Omega1 <- sigmaeps + Tn * sigmazeta + N * sigmaeta
    Omega2 <- sigmaeps + Tn * sigmazeta
    Omega3 <- sigmaeps +  N * sigmaeta
    Omega4 <- sigmaeps
    O1inv <- solve(Omega1)
    O2inv <- solve(Omega2)
    O3inv <- solve(Omega3)
    O4inv <- solve(Omega4)
    XOX <- X_invOmega_Y(HX, HX, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    XOy <- X_invOmega_Y(HX, Hy, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    #print(solve(XOX))
    beta <- solve(XOX, XOy)
    # vectors of residuals, each column is for a different "type"
    # this is a (N*Tn) * p matrix
    # inside each col, {t1, i1}, {t1, i2}, {t1, i3}, ...{t2, i1}, {t2, i2}, {t2, i3}..
    vit <- Hy - HX %*% beta
    negll <- 1/2 * (log(det(Omega1)) + (N-1) * log(det(Omega2)) +
                      (Tn-1) * log(det(Omega3)) + (N-1) * (Tn-1) * log(det(Omega4)) +
                      X_invOmega_Y(vit, vit, N, Tn, p,
                                   O1inv, O2inv, O3inv, O4inv))

    return(negll)

  }
}
