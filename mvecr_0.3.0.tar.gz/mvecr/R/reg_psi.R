#' Maximum likelihood estimation of the multivariate error components model, when one of the regressors is transformed by a single parameter function
#'
#' When one of the regressors depends on a parameter (\eqn{\psi}), adjust the corresponding variance of the regression coefficients and calculate the t statistic of \eqn{\psi}. Here we assume \eqn{f(x, \psi}) is a differentiable function of \eqn{x} with parameter \eqn{\psi}. The transformation function and its gradient should be provided as input parameters.
#' @param data.X Matrix of independent variables.
#' @param data.y Vector of dependent variables.
#' @param data.H Vector of number of observations in each t-i-p combination.
#' @param colName.i Column name in data that contains "district" information.
#' @param colName.t Column name in data that contains "time" information.
#' @param colName.p Column name in data that contains "type" information.
#' @param colName.Xpsi Name of the column x to be transformed by transform.func.
#' @param psi A numeric scalar of the \eqn{\psi} parameter.
#' @param transform.func A function of form \eqn{f(x, \psi)} which is used to transform the vector \eqn{data.X[, colName.Xpsi]}.
#' @param transform.gradient A function of form \eqn{g(x, \psi)}. This is the gradient of transform.func w.r.t. \eqn{\psi} and evaluated at \eqn{p}.
#' @param district Unique name of districts.
#' @param time Unique time periods in the data.
#' @param type Unique names of the type in the data.
#' @param var Vector of names of the columns in data.X to include in the regression.
#' @param par.include A vector of logical values indicating whether or not to include a certain error parameter in the regression. If FALSE, the parameter is constrained to be 0. The error parameters are the non-zero elements of the Cholesky decomposition of the variance-covariance matrices of each error component. The dimension of each error matrix will be \eqn{p\times p}, corresponding to \eqn{p*(1+p)/2} parameters. Default value of par.include is \eqn{rep(1, 18)} for a three error component model with \eqn{p=3}, where \eqn{p} is the number of distinct types (the length of vector in each t-i combination). The first \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\zeta}} (district specific error component), the second \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\eta}} (time specific error component), and the last \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\epsilon}} (individual specific error component).
#' @param par.init A vector of initial values of the parameters. Default value is 0.5 for each parameter. The number of parameters is \eqn{3*p*(1+p)/2}, where \eqn{p} is the number of types and 3 is the number of error components in the full model. Note that the parameters corresponding to the elements of "par.include" being FALSE are constrained to be 0, so even if initial parameters are specified for these parameters, they will not be used.
#' @return A data frame containing parameter estimates, t statistics, loglikelihood value, value of psi (given as input), and the t-statistic w.r.t. psi.
#' @references Ikefuji, M., Laeven, R. J., Magnus, J. R., & Yue, Y. (2020). Earthquake risk embedded in property prices: Evidence from five Japanese cities.
#' @examples
#' \dontrun{
#' vars_include <- c("constant_LandBldg", "constant_LandOnly", "constant_Condo",
#' "distance.num", "area.m2.num", "total.floor.area.m2.num", "building.age",
#' "LandBldg_RC", "LandBldg_S", "LandBldg_W", "built.1981_2000", "built.after2000",
#' "Urban_Control", "max.building.coverage.ratio", "max.floor.area.ratio",
#' "City_Fukuoka", "City_Nagoya", "City_Osaka", "City_Sapporo", "log.nGDP", "log.CPI",
#' "PctImmi", "Ncrime", "PctUnemploy", "PctExec", "JSHIS_I45_55", "JSHIS_I55", "Xpsi_obj")
#' data_vec <- vectorize(data = individual_data_sample, colName.i = "Area.Ward.City",
#' colName.t = "t", colName.p = "Type",
#' colName.y = "log.price",
#' colName.X = vars_include)
#' results <- reg_psi(data.X = data_vec$X, data.y = data_vec$y, data.H = data_vec$H,
#' colName.i = "Area.Ward.City", colName.t = "t",  colName.p = "Type", colName.Xpsi = "Xpsi_obj",
#' psi = 1, transform.func = prelec, transform.gradient = Z_prelec,
#' district = data_vec$district, time = data_vec$time, type = data_vec$type,
#' var = gsub("Xpsi_obj", "Xpsi", vars_include),
#' par.include = c(rep(1, 6), rep(0,6), rep(1,6)))
#' }
#' @export
reg_psi <- function(data.X, data.y, data.H,
                    colName.i, colName.t,  colName.p, colName.Xpsi,
                    psi = 1, transform.func, transform.gradient,
                    district, time, type,
                    var,
                    par.include = rep(1, 18),
                    par.init = rep(0.5, 18)){
    data.X$Xpsi <- 0
    # if(method == "p"){
    #   data.X$Xpsi <- ifelse(data.X$Xpsi_obj==0, 0, prelec(data.X$Xpsi_obj, psi = psi))
    #   z_psi <-  Z_prelec(p = (data.X$Xpsi_obj), psi = psi, log = FALSE)
    #   Hz <- as.vector(sqrt(data.H)) * z_psi
    # } else if(method == "t"){
    #   data.X$Xpsi <- ifelse(data.X$Xpsi_obj==0, 0, tversky(data.X$Xpsi_obj, psi = psi))
    #   z_psi <-  Z_tversky(p = (data.X$Xpsi_obj), psi = psi, log = FALSE)
    #   Hz <- as.vector(sqrt(data.H)) * z_psi
    # }
    data.X$Xpsi <- ifelse(data.X[, colName.Xpsi]==0, 0, transform.func(data.X[, colName.Xpsi], psi = psi))
    z_psi <-  transform.gradient(p = (data.X[, colName.Xpsi]), psi = psi, log = FALSE)
    Hz <- as.vector(sqrt(data.H)) * z_psi
    results <- ec_reg(data.X,  data.y, data.H,
                      colName.i, colName.t, colName.p,
                      var = var,
                      district = district, time = time, type = type,
                      par.include = par.include,
                      par.init = par.init)
    # given the regression results, reconstruct the variances
    N <- length(district)
    Tn <- length(time)
    p <- length(type)
    Hy <- as.vector(sqrt(data.H)) * data.y
    Hy[data.H==0] <- 0
    HX <- as.vector(sqrt(data.H)) * data.X[, var]
    HX[data.H==0, ] <- 0
    HX <- as.matrix(HX)
    npar <- sum(par.include!=0)
    par <- results$param_est[1:npar]
    full.par <- rep(0, 3*p*(p+1)/2)
    full.par[which(par.include!=0)] <- par
    full.par <- matrix(full.par, ncol=3, byrow = F)
    tmp <- matrix(0, p, p)
    L.zeta <- tmp
    L.zeta[lower.tri(tmp, diag = T)] <- full.par[, 1]
    diag(L.zeta) <- exp(diag(L.zeta)) * par.include[c(1, 4, 6)]
    L.eta <- tmp
    L.eta[lower.tri(tmp, diag = T)] <- full.par[, 2]
    diag(L.eta) <- exp(diag(L.eta)) * par.include[c(7, 10, 12)]
    L.eps <- tmp
    L.eps[lower.tri(tmp, diag = T)] <- full.par[, 3]
    diag(L.eps) <- exp(diag(L.eps)) * par.include[c(13, 16, 18)]
    # generate sigma_zeta, sigma_eta, sigma_eps
    sigmazeta <-  tcrossprod(L.zeta)
    sigmaeta <- tcrossprod(L.eta)
    sigmaeps <- tcrossprod(L.eps)
    Omega1 <- sigmaeps + Tn * sigmazeta + N * sigmaeta
    Omega2 <- sigmaeps + Tn * sigmazeta
    Omega3 <- sigmaeps +  N * sigmaeta
    Omega4 <- sigmaeps
    O1inv <- solve(Omega1)
    O2inv <- solve(Omega2)
    O3inv <- solve(Omega3)
    O4inv <- solve(Omega4)
    XOX <- X_invOmega_Y(HX, HX, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    XOy <- X_invOmega_Y(HX, Hy, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    V11inv <- solve(XOX)
    V12 <- X_invOmega_Y(HX, Hz, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    V21 <- X_invOmega_Y(Hz, HX, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    V22 <- X_invOmega_Y(Hz, Hz, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    beta <- solve(XOX, XOy)
    beta_k <- results$coef[which(results$var=="Xpsi")]
    var_beta <- V11inv + V11inv %*% V12 %*% V21 %*% V11inv /
      as.numeric((V22 - V21 %*% V11inv %*% V12))
    t_beta <- beta/sqrt(diag(var_beta))
    results$t.stat <- as.vector(t_beta)
    var_psi <- 1/ ( beta_k^2 * (V22 - V21 %*% V11inv %*% V12) )
    tstat_psi <- (psi-1) / sqrt(var_psi)
    results_psi <- rbind(results, c('psi', 0,0,0,0, psi, tstat_psi))
    for(i in colnames(results_psi)[-1]){
      results_psi[[i]] <- as.numeric(results_psi[[i]])
    }
  return(results_psi)
}
