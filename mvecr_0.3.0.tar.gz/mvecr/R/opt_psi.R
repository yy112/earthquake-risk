#' Optimization of the psi parameter used in the transformation of regressor in the multivariate error components model
#'
#' Given a list of psi parameter values,  this function finds the psi that maximizes loglikelihood by implementing a grid search.
#'
#' @param data.X Matrix of independent variables.
#' @param data.y Vector of dependent variables.
#' @param data.H Vector of number of observations in each i-t-p combination.
#' @param colName.i Column name in data that contains district information.
#' @param colName.t Column name in data that contains time information.
#' @param colName.p Column name in data that contains type information.
#' @param colName.Xpsi Name of the column x to be transformed by transform.func.
#' @param list.psi A numeric vector of the psi parameter.
#' @param transform.func A function of form \eqn{f(x, \psi)} which is used to transform the vector \eqn{data.X[, colName.Xpsi]}.
#' @param transform.gradient A function of form \eqn{g(x, \psi)}. This is the gradient of transform.func w.r.t. \eqn{\psi} and evaluated at \eqn{p}.
#' @param district Unique name of districts.
#' @param time Unique time periods in the data.
#' @param type Unique names of the type in the data.
#' @param var Vector of names of the columns in data.X to include in the regression.
#' @param par.include A vector of logical values indicating whether or not to include a certain error parameter in the regression. If FALSE, the parameter is constrained to be 0. The error parameters are the non-zero elements of the Cholesky decomposition of the variance-covariance matrices of each error component. The dimension of each error matrix will be \eqn{p\times p}, corresponding to \eqn{p*(1+p)/2} parameters. Default value of par.include is \eqn{rep(1, 18)} for a three error component model with \eqn{p=3}, where \eqn{p} is the number of distinct types (the length of vector in each t-i combination). The first \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\zeta}} (district specific error component), the second \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\eta}} (time specific error component), and the last \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\epsilon}} (individual specific error component).
#' @param par.init A vector of initial values of the parameters. Default value is 0.5 for each parameter. The number of parameters is \eqn{3*p*(1+p)/2}, where \eqn{p} is the number of types and 3 is the number of error components in the full model. Note that the parameters corresponding to the elements of "par.include" being FALSE are constrained to be 0, so even if initial parameters are specified for these parameters, they will not be used.
#' @return Numeric value of the psi parameter that maximizes loglikelihood.
#' @references Ikefuji, M., Laeven, R. J., Magnus, J. R., & Yue, Y. (2020). Earthquake risk embedded in property prices: Evidence from five Japanese cities.
#' @examples
#' \dontrun{
#' vars_include <- c("constant_LandBldg", "constant_LandOnly", "constant_Condo",
#' "distance.num", "area.m2.num", "total.floor.area.m2.num", "building.age",
#' "LandBldg_RC", "LandBldg_S", "LandBldg_W", "built.1981_2000", "built.after2000",
#' "Urban_Control", "max.building.coverage.ratio", "max.floor.area.ratio",
#' "City_Fukuoka", "City_Nagoya", "City_Osaka", "City_Sapporo", "log.nGDP", "log.CPI",
#' "PctImmi", "Ncrime", "PctUnemploy", "PctExec", "JSHIS_I45_55", "JSHIS_I55", "Xpsi_obj")
#' data_vec <- vectorize(data = individual_data_sample, colName.i = "Area.Ward.City",
#' colName.t = "t", colName.p = "Type",
#' colName.y = "log.price",
#' colName.X = vars_include)
#' list_results <- opt_psi(data.X = data_vec$X, data.y = data_vec$y, data.H = data_vec$H,
#' colName.i = "Area.Ward.City", colName.t = "t",  colName.p = "Type", colName.Xpsi = "Xpsi_obj",
#' list.psi = c(3, 3.5, 4), transform.func = prelec, transform.gradient = Z_prelec,
#' district = data_vec$district, time = data_vec$time, type = data_vec$type,
#' var = gsub("Xpsi_obj", "Xpsi", vars_include),
#' par.include = c(rep(1, 6), rep(0,6), rep(1,6)))
#' }
#' @export
opt_psi <- function(data.X, data.y, data.H,
                    colName.i, colName.t,  colName.p, colName.Xpsi,
                    list.psi = 1,
                    transform.func, transform.gradient,
                    district, time, type,
                    var,
                    par.include = rep(1, 18),
                    par.init = rep(0.5, 18)){
  list_logL <- numeric(length(list.psi))
  for(i in 1:length(list.psi)){
    res <- reg_psi(data.X, data.y, data.H,
                   colName.i=colName.i, colName.t=colName.t,
                   colName.p=colName.p, colName.Xpsi=colName.Xpsi,
                   psi = list.psi[i],
                   transform.func = transform.func,
                   transform.gradient = transform.gradient,
                   district = district, time = time, type = type,
                   var = var,
                   par.include,
                   par.init)
    list_logL[i] <- -res$negLL[1]
  }
  return(list(psi_ml=list.psi[which.max(list_logL)], list.psi=list.psi, list_logL=list_logL))
}
