#' X_invOmega_Y
#'
#' This function calculates the functions in the form \eqn{X'\Omega^{-1}y}.
#'
#' @param X Matrix or vector of dimension \eqn{N*Tn*p\times k_1}.
#' @param Y Matrix or vector of dimension \eqn{N*Tn*p\times k_2} .
#' @param N A numeric scalar, number of districts.
#' @param Tn A numeric scalar, number of time periods.
#' @param p A numeric scalar, number of dimensions (covariates).
#' @param O1inv A matrix of dimension \eqn{p\times p}, component of the \eqn{\Omega} matrix.
#' @param O2inv A matrix of dimension \eqn{p\times p}, component of the \eqn{\Omega} matrix.
#' @param O3inv A matrix of dimension \eqn{p\times p}, component of the \eqn{\Omega} matrix.
#' @param O4inv A matrix of dimension \eqn{p\times p}, component of the \eqn{\Omega} matrix.
#'
#' @return \eqn{X'\Omega^{-1}Y}
#' @references Ikefuji, M., Laeven, R. J., Magnus, J. R., & Yue, Y. (2020). Earthquake risk embedded in property prices: Evidence from five Japanese cities.
#' @export

X_invOmega_Y <- function(X, Y, N, Tn, p,
                         O1inv, O2inv, O3inv, O4inv){
  # X and Y are of dimensions (NTp)*k, k can be different
  # Deltas are of dimension p*p
  # number of cols of X and Y
  k1 <- ifelse(length(ncol(X))==0, 1, ncol(X))
  k2 <- ifelse(length(ncol(Y))==0, 1, ncol(Y))
  X <- as.matrix(X, ncol=k1)
  Y <- as.matrix(Y, ncol=k2)

  term1 <- matrix(0, nrow = k1, ncol = k2)
  if(!all((O1inv - O2inv - O3inv + O4inv)==0)){
    sum_it_X <- matrix(0, nrow = p, ncol = k1)
    sum_it_Y <- matrix(0, nrow = p, ncol = k2)
    for(it in 1:(N*Tn)){
      sum_it_X <- sum_it_X + X[((it-1)*p+1):(it*p), ]
      sum_it_Y <- sum_it_Y +  Y[((it-1)*p+1):(it*p), ]
    }
    term1 <- t(sum_it_X) %*% (O1inv - O2inv - O3inv + O4inv) %*%
      as.matrix(sum_it_Y)
  }



  term2 <- matrix(0, nrow = k1, ncol = k2)
  if(!all((O2inv - O4inv)==0)){
    for(i in 1:N){
      sumtXDsumtY <- matrix(0, nrow = k1, ncol = k2)
      sumtX <- matrix(0, nrow = p, ncol = k1)
      sumtY <- matrix(0, nrow = p, ncol = k2)
      for(t in 1:Tn){
        sumtX <- sumtX +
          (X[(((t-1)*N+i-1)*p+1):(((t-1)*N+i)*p), ])
        sumtY <- sumtY +
          (Y[(((t-1)*N+i-1)*p+1):(((t-1)*N+i)*p), ])
      }
      sumtXDsumtY <- t(sumtX) %*% (O2inv - O4inv) %*%
        as.matrix(sumtY)
      term2 <- term2 + sumtXDsumtY
    }
  }



  term3 <- matrix(0, nrow = k1, ncol = k2)
  if(!all((O3inv - O4inv)==0)){
    for(t in 1:Tn){
      sumiXDsumiY <- matrix(0, nrow = k1, ncol = k2)
      sumiX <- matrix(0, nrow = p, ncol = k1)
      sumiY <- matrix(0, nrow = p, ncol = k2)
      for(i in 1:N){
        sumiX <- sumiX +
          X[(((t-1)*N+i-1)*p+1):(((t-1)*N+i)*p), ]
        sumiY <- sumiY +
          Y[(((t-1)*N+i-1)*p+1):(((t-1)*N+i)*p), ]
      }
      sumiXDsumiY <- t(sumiX) %*%
        (O3inv - O4inv) %*%
        as.matrix(sumiY)
      term3 <- term3 + sumiXDsumiY
    }
  }


  term4 <- matrix(0, nrow = k1, ncol = k2)
  if(!all(O4inv==0) & length(O4inv)!=1){
    for(it in 1:(N*Tn)){
      term4 <- term4 + t(X[((it-1)*p+1):(it*p), ]) %*%
        O4inv %*% as.matrix(Y[((it-1)*p+1):(it*p), ])
    }
  }else if(!all(O4inv==0) & length(O4inv)==1){
    for(it in 1:(N*Tn)){
      term4 <- term4 + as.numeric(O4inv) *
        as.matrix(X[((it-1)*p+1):(it*p), ]) %*% t(as.matrix(Y[((it-1)*p+1):(it*p), ]))
    }
  }


  XOY <- (1/N)*(1/Tn)*term1 + (1/Tn)*term2 +
    (1/N)*term3 + term4
  return(XOY)
}

