#' Gradient of the loglikelihood function of the multivariate error component model
#'
#' This function is the gradient function of the multivariate error component model.
#'
#' @param par A vector of parameters corresponding to the Cholesky decomposition of the error matrices, that is, \eqn{\Sigma=LL'} where \eqn{L} is a lower triangular matrix with positive diagonal elements). This vector is of length \eqn{3*p*(p+1)/2}, where 3 comes from the three error components. However, note that only the parameters corresponding to include=TRUE are included in the models while others are constrained to be 0. The first \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\zeta}} (district specific error component), the second \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\eta}} (time specific error component), and the last \eqn{p*(1+p)/2} parameters correspond to the error matrix \eqn{\Sigma_{\eps}} (individual specific error component).
#' @param include A vector of logical values with the same dimension as par, indicating whether the parameter should be included as one of the values to optimize on. If a certain element corresponds to include=FALSE, that parameter is constrained to be 0. Hence, for a "full" three error component model, set include=rep(1, \eqn{3*p*(p+1)/2}); for a two error component model with only district specific and individual specific errors, set include=c(rep(1, \eqn{p*(p+1)/2}), rep(0, \eqn{p*(p+1)/2}), rep(1, \eqn{p*(p+1)/2})).
#' @param N A numeric scalar, number of districts.
#' @param Tn A numeric scalar, number of time periods.
#' @param p A numeric scalar, number of types.
#' @param HX A numeric matrix of independent variables, with dimension \eqn{N*Tn*p\times k_1} where \eqn{k_1} is the number of regressors.
#' @param Hy A numeric vector of dependent variables, with dimension \eqn{N*Tn*p\times 1}.
#'
#' @return A vector of the gradient of the multivariate error component model.
#' @references Ikefuji, M., Laeven, R. J., Magnus, J. R., & Yue, Y. (2020). Earthquake risk embedded in property prices: Evidence from five Japanese cities.
#' @export

gradient <- function(par, include, N, Tn, HX, Hy, p){
  npar <- length(par)
  full.par <- rep(0, 3*p*(p+1)/2)
  full.par[which(include!=0)] <- par
  full.par <- matrix(full.par, ncol=3, byrow = F)
  tmp <- matrix(0, p, p)
  eye <- diag(1, p)
  if(npar != sum(include) | length(include)!=(3*p*(p+1)/2)){
    print("number of parameters do not match")
  } else if(p==3){
    L.zeta <- tmp
    L.zeta[lower.tri(tmp, diag = T)] <- full.par[, 1]
    diag(L.zeta) <- exp(diag(L.zeta)) * include[c(1, 4, 6)]
    L.eta <- tmp
    L.eta[lower.tri(tmp, diag = T)] <- full.par[, 2]
    diag(L.eta) <- exp(diag(L.eta)) * include[c(7, 10, 12)]
    L.eps <- tmp
    L.eps[lower.tri(tmp, diag = T)] <- full.par[, 3]
    diag(L.eps) <- exp(diag(L.eps)) * include[c(13, 16, 18)]
    # generate sigma_zeta, sigma_eta, sigma_eps
    sigmazeta <-  tcrossprod(L.zeta)
    sigmaeta <- tcrossprod(L.eta)
    sigmaeps <- tcrossprod(L.eps)
    # generate Omega matrices
    Omega1 <- sigmaeps + Tn * sigmazeta + N * sigmaeta
    Omega2 <- sigmaeps + Tn * sigmazeta
    Omega3 <- sigmaeps +  N * sigmaeta
    Omega4 <- sigmaeps
    O1inv <- solve(Omega1)
    O2inv <- solve(Omega2)
    O3inv <- solve(Omega3)
    O4inv <- solve(Omega4)
    XOX <- X_invOmega_Y(HX, HX, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    XOy <- X_invOmega_Y(HX, Hy, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    beta <- solve(XOX, XOy)
    vit <- Hy - HX %*% beta
    vOX <- X_invOmega_Y(vit, HX, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    gr <- rep(0, 3*p*(p+1)/2)
    for(m in 1:(3*p*(p+1)/2)){
      if(include[m]!=0){
        n.mat <- ceiling(m/(p*(p+1)/2))
        j <- which((m - (p*(p+1)/2)*(n.mat-1)) <=
                     cumsum(seq(p,1,-1)))[1]
        i <- 3 + m - (p*(p+1)/2)*(n.mat-1) -
          cumsum(seq(p,1,-1))[j]
        ei <- matrix(0, nrow = p, ncol = 1)
        ei[i, 1] <- 1
        ej <- matrix(0, nrow = p, ncol = 1)
        ej[j, 1] <- 1
        # term1: tr(inv(Omega) dOmega)
        if(n.mat==1){
          eeL <-  ei %*% t(ej) %*%  t(L.zeta) +
            L.zeta %*% ej %*% t(ei)
          term1 <- (Tn*sum(diag(O1inv %*% eeL+(N-1)*O2inv %*% eeL)))*
            ifelse(i==j, L.zeta[i, j], 1)
          dE1 <- Tn * O1inv %*% eeL %*% O1inv *
            ifelse(i==j, L.zeta[i, j], 1)
          dE2 <- Tn * O2inv %*% eeL %*% O2inv *
            ifelse(i==j, L.zeta[i, j], 1)
          dE3 <- 0
          dE4 <- 0
        } else if(n.mat==2) {
          eeL <-  ei %*% t(ej) %*%  t(L.eta) +
            L.eta %*% ej %*% t(ei)
          term1 <- (N*sum(diag(O1inv %*% eeL+(Tn-1)*O3inv %*% eeL)))*
            ifelse(i==j, L.eta[i, j], 1)
          dE1 <- N * O1inv %*% eeL %*% O1inv *
            ifelse(i==j, L.eta[i, j], 1)
          dE2 <- 0
          dE3 <- N * O3inv %*% eeL %*% O3inv *
            ifelse(i==j, L.eta[i, j], 1)
          dE4 <- 0
        } else if(n.mat==3){
          eeL <-  ei %*% t(ej) %*%  t(L.eps) +
            L.eps %*% ej %*% t(ei)
          term1 <- (sum(diag(O1inv %*% eeL + (N - 1)*O2inv %*% eeL +
                               (Tn - 1)*O3inv %*% eeL +
                               (N - 1)*(Tn -1 )*O4inv %*% eeL))) *
            ifelse(i==j, L.eps[i, j], 1)
          dE1 <- O1inv %*% eeL %*% O1inv *
            ifelse(i==j, L.eps[i, j], 1)
          dE2 <- O2inv %*% eeL %*% O2inv *
            ifelse(i==j, L.eps[i, j], 1)
          dE3 <- O3inv %*% eeL %*% O3inv *
            ifelse(i==j, L.eps[i, j], 1)
          dE4 <- O4inv %*% eeL %*% O4inv *
            ifelse(i==j, L.eps[i, j], 1)
        }
        term2 <- vOX %*% solve(XOX) %*%
          X_invOmega_Y(HX, vit, N, Tn, p, dE1, dE2, dE3, dE4)
        term3 <- X_invOmega_Y(vit, vit, N, Tn, p,
                              dE1, dE2, dE3, dE4)
        gr[m] <-  1/2 * term1 + term2 - 1/2 * term3

      }
    }
  }else if(p==1){
    L.zeta <- exp(full.par[, 1]) * include[1]
    L.eta <- exp(full.par[, 2]) * include[2]
    L.eps <- exp(full.par[, 3]) * include[3]
    # generate sigma_zeta, sigma_eta, sigma_eps
    sigmazeta <-  tcrossprod(L.zeta)
    sigmaeta <- tcrossprod(L.eta)
    sigmaeps <- tcrossprod(L.eps)
    # generate Omega matrices
    Omega1 <- sigmaeps + Tn * sigmazeta + N * sigmaeta
    Omega2 <- sigmaeps + Tn * sigmazeta
    Omega3 <- sigmaeps +  N * sigmaeta
    Omega4 <- sigmaeps
    O1inv <- solve(Omega1)
    O2inv <- solve(Omega2)
    O3inv <- solve(Omega3)
    O4inv <- solve(Omega4)
    XOX <- X_invOmega_Y(HX, HX, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    XOy <- X_invOmega_Y(HX, Hy, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    beta <- solve(XOX, XOy)
    vit <- Hy - HX %*% beta
    vOX <- X_invOmega_Y(vit, HX, N, Tn, p,
                        O1inv, O2inv, O3inv, O4inv)
    gr <- rep(0, 3*p*(p+1)/2)
    for(m in 1:(3*p*(p+1)/2)){
      if(include[m]!=0){
        n.mat <- ceiling(m/(p*(p+1)/2))
        j <- which((m - (p*(p+1)/2)*(n.mat-1)) <=
                     cumsum(seq(p,1,-1)))[1]
        i <- 3 + m - (p*(p+1)/2)*(n.mat-1) -
          cumsum(seq(p,1,-1))[j]
        ei  <- 1
        ej  <- 1
        # term1: tr(inv(Omega) dOmega)
        if(n.mat==1){
          eeL <-  ei %*% t(ej) %*%  t(L.zeta) +
            L.zeta %*% ej %*% t(ei)
          term1 <- (Tn*sum(diag(O1inv %*% eeL+(N-1)*O2inv %*% eeL)))*
            ifelse(i==j, L.zeta[i, j], 1)
          dE1 <- Tn * O1inv %*% eeL %*% O1inv *
            ifelse(i==j, L.zeta[i, j], 1)
          dE2 <- Tn * O2inv %*% eeL %*% O2inv *
            ifelse(i==j, L.zeta[i, j], 1)
          dE3 <- 0
          dE4 <- 0
        } else if(n.mat==2) {
          eeL <-  ei %*% t(ej) %*%  t(L.eta) +
            L.eta %*% ej %*% t(ei)
          term1 <- (N*sum(diag(O1inv %*% eeL+(Tn-1)*O3inv %*% eeL)))*
            ifelse(i==j, L.eta[i, j], 1)
          dE1 <- N * O1inv %*% eeL %*% O1inv *
            ifelse(i==j, L.eta[i, j], 1)
          dE2 <- 0
          dE3 <- N * O3inv %*% eeL %*% O3inv *
            ifelse(i==j, L.eta[i, j], 1)
          dE4 <- 0
        } else if(n.mat==3){
          eeL <-  ei %*% t(ej) %*%  t(L.eps) +
            L.eps %*% ej %*% t(ei)
          term1 <- (sum(diag(O1inv %*% eeL + (N - 1)*O2inv %*% eeL +
                               (Tn - 1)*O3inv %*% eeL +
                               (N - 1)*(Tn -1 )*O4inv %*% eeL))) *
            ifelse(i==j, L.eps[i, j], 1)
          dE1 <- O1inv %*% eeL %*% O1inv *
            ifelse(i==j, L.eps[i, j], 1)
          dE2 <- O2inv %*% eeL %*% O2inv *
            ifelse(i==j, L.eps[i, j], 1)
          dE3 <- O3inv %*% eeL %*% O3inv *
            ifelse(i==j, L.eps[i, j], 1)
          dE4 <- O4inv %*% eeL %*% O4inv *
            ifelse(i==j, L.eps[i, j], 1)
        }
        term2 <- vOX %*% solve(XOX) %*%
          X_invOmega_Y(HX, vit, N, Tn, p, dE1, dE2, dE3, dE4)
        term3 <- X_invOmega_Y(vit, vit, N, Tn, p,
                              dE1, dE2, dE3, dE4)
        gr[m] <-  1/2 * term1 + term2 - 1/2 * term3

      }
    }
  }
  gr <- gr[which(include!=0)]
  return(gr)
}

