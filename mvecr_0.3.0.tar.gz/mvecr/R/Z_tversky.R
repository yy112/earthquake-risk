#' Derivative of the "Tversky and Kahneman" probability weighting function
#'
#' A function that calculates the first derivative of the probability weighting function w.r.t. its parameter.
#' @param p Original probability, numeric value between 0 and 1.
#' @param psi Parameter of the function (single parameter form).
#' @param log Logical value indicating whether the weighted probability is taken natural logarithm. Default value is FALSE.
#'
#' @return Derivative of the "Tversky and Kahneman" function w.r.t. psi evaluated at p, a numeric value.
#'
#' @examples
#' Z_tversky(0.5,3)
#' Z_tversky(0.5, 0.5, log = TRUE)
#'
#' @export
Z_tversky <- function(p, psi, log = FALSE){
  if(log == FALSE){
    z <- ifelse(p!=0,  p^psi / (p^psi + (1-p)^psi)^(1/psi) *
                  (log(p) + 1/psi^2 * (log(p^psi + (1-p)^psi)) -
                     1/psi * (p^psi * log(p) + (1-p)^psi * log(1-p) )/(p^psi + (1-p)^psi)),
                0)
  } else{
    z <- ifelse(p!=0,  log(p) + 1/psi^2 * (log(p^psi + (1-p)^psi)) -
                  1/psi * (p^psi * log(p) + (1-p)^psi * log(1-p) )/(p^psi + (1-p)^psi),
                0)
  }
  return(z)
}
